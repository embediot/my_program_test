#include <stdio.h>
#include "inc/coordinate.h"

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;

    //printf("Hello World!\n");

    coordinate_test_function();

    return 0;
}
