#ifndef __POLYMORPHISM_TEST_H_
#define __POLYMORPHISM_TEST_H_

using namespace std;

//声明一个基类 - 坐标类 Coordinate
class Coordinate{
public:
    Coordinate(int x = 0, int y = 0);                //构造函数
    virtual void display_params();                    //虚函数，用来显示基类的信息

protected:
    int m_x;     //坐标x-属性
    int m_y;     //坐标y-属性 
};

//声明一个派生类 Rectangle，继承坐标类Coordinate
class Rectangle:public Coordinate{
public:
    Rectangle(int x, int y, int width, int height);      //构造函数
    virtual void display_params();                       //虚函数，用来显示派生类的信息

private:
    int m_width;   //宽-属性
    int m_height;  //高-属性
};

#endif
