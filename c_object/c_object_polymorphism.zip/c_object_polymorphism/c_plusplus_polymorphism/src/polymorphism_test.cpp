#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include "inc/polymorphism_test.h"

//基类 Coordinate 的构造函数
Coordinate::Coordinate(int x, int y) \
    :m_x(x),m_y(y)
{
    
}

//基类 Coordinate 的显示信息函数
void Coordinate::display_params()
{
    cout << "Class Coordinate x = " << this->m_x << " y = " << this->m_y << endl;
}

//派生类 Rectangle 的构造函数
Rectangle::Rectangle(int x, int y, int width, int height) \
    :Coordinate(x, y),m_width(width),m_height(height)
{
    
}

//派生类 Rectangle 的显示信息函数
void Rectangle::display_params()
{
    cout << "Class Rectangle width = " << this->m_width << " height = " << this->m_height << endl; 
}

