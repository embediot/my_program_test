#include <iostream>
#include <inc/polymorphism_test.h>

using namespace std;

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;

    Coordinate *p_base;

    Coordinate m_coordinate(10,10);

    p_base = &m_coordinate;

    p_base->display_params();

    Rectangle m_rectangle(0,0,100,150);

    p_base = &m_rectangle;

    p_base->display_params();

    return 0;
}
