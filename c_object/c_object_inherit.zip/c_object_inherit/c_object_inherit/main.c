#include <stdio.h>
#include "inc/rectangle.h"

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;

    //printf("Hello World!\n");

    rectangle_test_function();

    return 0;
}
