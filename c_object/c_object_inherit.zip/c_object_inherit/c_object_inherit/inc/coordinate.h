#ifndef __COORDINATE_H_
#define __COORDINATE_H_

//声明一个位置类，属性为坐标x，y，提供属性操作函数
typedef struct coordinate
{
    short int x;
    short int y;

    void (*moveby)(struct coordinate *p_coordinate,short int dx,short int dy);
    short int (*get_x)(struct coordinate *p_coordinate);
    short int (*get_y)(struct coordinate *p_coordinate);
}COORDINATE_T,*P_COORDINATE_T;

extern void coordinate_init(P_COORDINATE_T p_coordinate,short int x,short int y);
extern void coordinate_uninit(P_COORDINATE_T p_coordinate);

#endif // !__COORDINATE_H_

