#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "inc/coordinate.h"

//修改coordinate的属性值
static void coordinate_moveby(struct coordinate *p_coordiante,short int dx,short int dy)
{
    if(NULL != p_coordiante){
        p_coordiante->x += dx;
        p_coordiante->y += dy;
    }
}

//获取coordinate的属性值x
static short int coordinate_get_x(struct coordinate *p_coordiante)
{
    return (NULL != p_coordiante) ? p_coordiante->x : -1;
}

//获取coordinate的属性值y
static short int coordinate_get_y(struct coordinate *p_coordiante)
{
    return (NULL != p_coordiante) ? p_coordiante->y : -1;
}

//创建一个coordinate对象
void coordinate_init(P_COORDINATE_T p_coordinate,short int x,short int y)
{
    if((x < 0) || (y < 0) || (NULL == p_coordinate)){
        printf("coordinate create error! x or y can not be less than zero \n");
        return;
    }

    p_coordinate->x = x;
    p_coordinate->y = y;
    p_coordinate->moveby = coordinate_moveby;
    p_coordinate->get_x = coordinate_get_x;
    p_coordinate->get_y = coordinate_get_y;
}

//销毁一个coordinate对象
void coordinate_uninit(P_COORDINATE_T p_coordinate)
{
    if(NULL != p_coordinate){
        p_coordinate->x = -1;
        p_coordinate->y = -1;
        p_coordinate->moveby = NULL;
        p_coordinate->get_x = NULL;
        p_coordinate->get_y = NULL;
    }
}



