#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "inc/rectangle.h"

//创建一个rectangle类对象
P_RECTANGLE_T rectangle_create(short int x,short int y,unsigned short width,unsigned short height)
{
    P_RECTANGLE_T p_rectangle = NULL;

    p_rectangle = (P_RECTANGLE_T)malloc(sizeof(RECTANGLE_T));

    if(NULL != p_rectangle){       
        p_rectangle->width = width;
        p_rectangle->height = height;

        coordinate_init(&(p_rectangle->coordinate),x,y);
    }
    else{
        printf("rectangle create error! \n");
    }
    

    return p_rectangle;
}

//销毁一个rectangle类对象
void rectangle_destroy(P_RECTANGLE_T p_rectangle)
{
    coordinate_uninit(&(p_rectangle->coordinate));

    if(NULL != p_rectangle){
        free(p_rectangle);
        p_rectangle = NULL;
    }
}





//测试函数，在main中调用，用于测试类 rectangle 的接口
void rectangle_test_function(void)
{
    P_RECTANGLE_T p_rectangle_1 = NULL;
    P_RECTANGLE_T p_rectangle_2 = NULL;

    //创建两个 P_RECTANGLE_T 类型的类对象
    p_rectangle_1 = (P_RECTANGLE_T)rectangle_create(0,0,150,150);
    p_rectangle_2 = (P_RECTANGLE_T)rectangle_create(200,200,500,500);

    if((NULL != p_rectangle_1) && (NULL != p_rectangle_2)){

        //打印出类对象的初始化属性，通过函数指针的方式来调用属性操作函数
        printf("p_rectangle_1,x = %d,y = %d,width = %d,height = %d \n",\
               p_rectangle_1->coordinate.get_x(&(p_rectangle_1->coordinate)), \
               p_rectangle_1->coordinate.get_y(&(p_rectangle_1->coordinate)), \
               p_rectangle_1->width,p_rectangle_1->height);

        printf("p_rectangle_2,x = %d,y = %d,width = %d,height = %d \n",    \
               p_rectangle_2->coordinate.get_x(&(p_rectangle_2->coordinate)),   \
               p_rectangle_2->coordinate.get_y(&(p_rectangle_2->coordinate)),   \
               p_rectangle_2->width,p_rectangle_2->height);

        //修改类对象的属性，注意这里有两种方式，1、通过强制类型转换修改。2、通过正常方式修改
        p_rectangle_1->coordinate.moveby((P_COORDINATE_T)p_rectangle_1, 50, 50);
        p_rectangle_2->coordinate.moveby(&(p_rectangle_2->coordinate), 50, 50);

        //再次打印出类对象的修改后的属性
        printf("after moveby, p_rectangle_1,x = %d,y = %d,width = %d,height = %d \n",\
               p_rectangle_1->coordinate.get_x(&(p_rectangle_1->coordinate)), \
               p_rectangle_1->coordinate.get_y(&(p_rectangle_1->coordinate)), \
               p_rectangle_1->width,p_rectangle_1->height);

        printf("after moveby, p_rectangle_2,x = %d,y = %d,width = %d,height = %d \n",    \
               p_rectangle_2->coordinate.get_x(&(p_rectangle_2->coordinate)),   \
               p_rectangle_2->coordinate.get_y(&(p_rectangle_2->coordinate)),   \
               p_rectangle_2->width,p_rectangle_2->height);
    }

    //销毁类对象
    rectangle_destroy(p_rectangle_1);
    rectangle_destroy(p_rectangle_2);
}


